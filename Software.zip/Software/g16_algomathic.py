import argparse
from check_func import check
import subprocess
import time
import os
from pathlib import Path
import logging
import glob

# This version was used as is to produce the results in "Computation of Non-Radiative Rates
# for High-Throughput Virtual Screening: Application to Discovery of Potential TADF Molecules",
# Teodoro Pizza, Alessandro Troisi and Amedeo Capobianco.
# A polished version will be produced at the completion of the peer-review process.


with open('sample.log', 'w') as mp:
    pass

logging.basicConfig(
    level=logging.INFO,  # levels: DEBUG, INFO, WARNING, ERROR, CRITICAL
    format='%(asctime)s - %(levelname)s - %(message)s',
    filename='sample.log',
    filemode='a'
)


def send_computations(path):
    logging.info(f"Starting computations for molecules in {path}\n")
    subprocess.run(["creafile", "sbatch_inpfile.txt"], cwd=path)  # Create "sbatch_array"
    result = subprocess.run(["sbatch", "sbatch_array.sh"], capture_output=True, text=True, cwd=path)  # Submit jobs

    job_id = None  # Initialise before conditional assignment to avoid UnboundLocalError
    if result.returncode == 0 and "Submitted batch job" in result.stdout:
        output = result.stdout.strip()
        job_id = output.split()[-1]
        logging.info(f"Job submitted with ID: {job_id}")
    else:
        logging.error(f"Error while submitting sbatch script: {result.stderr}")
        raise RuntimeError("Error while submitting sbatch script")

    # Step 2: wait for job completion
    if job_id:
        while True:
            job = subprocess.run(["sacct", "-j", job_id, "--format=State", "--noheader"],
                                 capture_output=True, text=True)
            states = [s.strip() for s in job.stdout.splitlines() if s.strip()]

            if all(s == "COMPLETED" for s in states):
                return True

            if any(s in ["FAILED", "CANCELLED", "TIMEOUT"] for s in states):
                logging.error(f"Job {job_id} failed with states: {states}")
                raise RuntimeError(f"Job {job_id} failed with states: {states}")

            time.sleep(120)  # Check every 2 minutes


def convergence(listinput, outfile):
    logging.info(f"Checking convergence for molecules in {listinput}\n")
    message: list[str] = check(input_dirs=[listinput], output=outfile, not_conv=True)
    molid: list[str] = []

    while message:
        if any('discarded' in g for g in message):
            # Molecules to be discarded
            for mex in message:
                if 'discarded' in mex:
                    molid.append(mex.strip().split()[0])
            return molid
        else:
            logging.info(f"Convergence not reached for all molecules in {listinput}\n")
            # Some molecules failed to converge (first/second attempt)
            send_computations(listinput)
            removeslurm(listinput)

            # Re-check convergence after computations
            message = check(input_dirs=[listinput], output=outfile, not_conv=True)
    else:
        # No convergence issues
        logging.info(f"Convergence reached for all molecules in {listinput}\n")
        return molid


def imaginary_freq(listinput, outfile):
    logging.info(f"Checking for imaginary frequencies in {listinput}\n")
    subprocess.run("module load gaussian/16 && super_fchk.sh", shell=True, cwd=listinput)

    message: list[str] = check(input_dirs=[listinput], output=outfile, nfreq=True)
    molid: list[str] = []
    counter = 0

    while message and counter < 3:  # Imaginary frequencies found (max 3 attempts)
        logging.info(f"Imaginary frequencies detected for some molecules in {listinput}\n")
        send_computations(listinput)
        removeslurm(listinput)
        message = check(input_dirs=[listinput], output=outfile, nfreq=True)
        counter += 1

    # Remove generated fchk files regardless of outcome
    files = glob.glob(f"{listinput}/*.fchk")
    for f in files:
        subprocess.run(["rm", f])

    if message:
        logging.warning(f"Imaginary frequencies still present after {counter} attempts in {listinput}\n")


def removeslurm(path):
    for f in glob.glob(f"{path}/slurm*.out"):
        Path(f).unlink(missing_ok=True)


def createformchk(path):
    result = subprocess.run("module load gaussian/16 && super_fchk.sh", capture_output=True, text=True, cwd=path,
                            shell=True)
    if result.returncode != 0:
        raise Exception(f"Couldn't create formatted checkpoint files in {path}\n")


def main():
    inp = argparse.ArgumentParser(description="Automated workflow")

    inp.add_argument("-i", "--input", help="Path to input files", required=True)
    inp.add_argument("-o", "--output", help="Output filename", required=True)

    args = inp.parse_args()

    s0path = Path(args.input)
    s0output = s0path / args.output

    # FIRST STEP: CHECK S0 CONVERGENCE
    discarded_molecules = convergence(s0path, s0output)
    createformchk(s0path)

    # SECOND STEP: VERTICAL COMPUTATIONS

    # T1 TD-DFT at S0 geometry
    logging.info("Starting T1 vertical computations")

    if discarded_molecules:  # Some molecules must be discarded
        for disc in discarded_molecules:
            discchk = Path(disc).with_suffix(".chk")
            discout = Path(disc).with_suffix(".out")
            # Remove S0 chk files of discarded molecules
            discchk.unlink(missing_ok=True)
            discout.unlink(missing_ok=True)

    t1vertpath = s0path / 'verticale/t1'
    os.makedirs(f"{t1vertpath}", exist_ok=True)

    # Generate new input files from S0 chk
    check(comp=True, path=s0path, newext='_t1_vert', newpath=t1vertpath,
          method='td(nstates=3,root=1,triplets)', vert=True)

    # Submit T1 vertical jobs
    send_computations(t1vertpath)
    removeslurm(t1vertpath)

    t1vertoutput = t1vertpath / args.output
    discarded_flagged = check(input_dirs=[t1vertpath], output=t1vertoutput,
                              de_excitations=True, energy=True)

    if discarded_flagged:
        for disflag in discarded_flagged:
            if 'discarded' in disflag:
                disc = disflag.strip().split()[0]
                discarded_molecules.append(disc)

                disc = disc.replace('_t1_vert.chk', '.chk')
                discnoext = s0path / Path(disc).stem
                discchk = discnoext.with_suffix(".chk")
                discout = discnoext.with_suffix(".out")
                # Remove discarded molecules from S0
                discchk.unlink(missing_ok=True)
                discout.unlink(missing_ok=True)

    # S1 TD-DFT at S0 geometry
    logging.info("Starting S1 vertical computations\n")

    s1vertpath = s0path / 'verticale/s1'
    os.makedirs(f"{s1vertpath}", exist_ok=True)

    check(comp=True, path=s0path, newext='_s1_vert', newpath=s1vertpath,
          method='td(nstates=3,root=1)', vert=True)

    send_computations(s1vertpath)
    removeslurm(s1vertpath)

    s1vertoutput = s1vertpath / args.output
    discarded_flagged = check(input_dirs=[s1vertpath], output=s1vertoutput,
                              de_excitations=True, energy=True)

    if discarded_flagged:
        for disflag in discarded_flagged:
            if 'discarded' in disflag:
                disc = disflag.strip().split()[0]
                discarded_molecules.append(disc)

                disc = disc.replace('_s1_vert.chk', '.chk')
                discnoext = s0path / Path(disc).stem
                discchk = discnoext.with_suffix(".chk")
                discout = discnoext.with_suffix(".out")
                # Remove discarded molecules from S0
                discchk.unlink(missing_ok=True)
                discout.unlink(missing_ok=True)

    # THIRD STEP: T1 DeltaSCF optimizations
    logging.info("Starting T1 DeltaSCF optimization\n")

    t1scfpath = s0path.parent / "T1"
    os.makedirs(f"{t1scfpath}", exist_ok=True)

    check(comp=True, path=s0path, newext='_t1', newpath=t1scfpath, method='DSCF')

    send_computations(t1scfpath)
    removeslurm(t1scfpath)
    createformchk(t1scfpath)

    logging.info("Computation completed!\n")

    t1scfoutput = t1scfpath / args.output

    # Check convergence of T1
    conv = convergence(t1scfpath, t1scfoutput)
    if conv:  # Some molecules did not converge
        discarded_molecules.extend(conv)

        for c in conv:
            cpath = Path(c)
            disc = t1scfpath / cpath.stem
            discs0 = s0path / cpath.stem
            discs0 = discs0.with_name(discs0.name.replace('_t1', ''))

            # Remove problematic molecules from S0
            subprocess.run(["rm", f"{disc}.chk", f"{disc}.out",
                            f"{discs0}.out", f"{discs0}.chk"])

    # Connectivity check
    logging.info(f"Checking connectivity between {s0path} and {t1scfpath}")
    connectivity_check = check(input_dirs=[s0path, t1scfpath],
                               output=t1scfoutput, connectivity=True)

    if connectivity_check:
        for cc in connectivity_check:
            cc = cc.strip().split()[0]
            pathcc = Path(cc)

            discarded_molecules.append(cc)

            discs0 = s0path / pathcc.stem
            disc = t1scfpath / pathcc.stem

            discs0 = discs0.with_name(discs0.name.replace('_t1', ''))

            # Remove inconsistent molecules from S0 and T1
            subprocess.run(["rm", f"{discs0}.chk", f"{discs0}.out",
                            f"{disc}.out", f"{disc}.chk"])

    # FOURTH STEP: frequency calculations (S0, T1, S1)
    logging.info("Starting S0 frequency computation")

    s0freqpath = s0path / "freq"
    os.makedirs(f"{s0freqpath}", exist_ok=True)

    check(comp=True, path=s0path, newext='_freq', newpath=s0freqpath,
          method='freq=hpmodes')

    send_computations(s0freqpath)
    removeslurm(s0freqpath)
    createformchk(s0freqpath)

    logging.info("Computation completed!\n")

    s0freqoutput = s0freqpath / args.output

    # Check for imaginary frequencies
    imaginary_freq(s0freqpath, s0freqoutput)


if __name__ == "__main__":
    main()
