import argparse
from check_func import check
import subprocess
import time
import os
from pathlib import Path
import logging
import glob

# This code is specifically configured to run in the author's local computational environment
# and was used as-is to produce the results in "Computation of Non-Radiative Rates for High-Throughput
# Virtual Screening: Application to Discovery of Potential TADF Molecules" by Teodoro Pizza, Alessandro Troisi and Amedeo Capobianco.

with open('sample.log','w') as mp:
    pass
# Basic configuration
logging.basicConfig(
    level=logging.INFO,  # levels: DEBUG, INFO, WARNING, ERROR, CRITICAL
    format='%(asctime)s - %(levelname)s - %(message)s',
    filename='sample.log',  # (optional) writes to file
    filemode='a'  # 'w' to overwrite, 'a' to append
)

def send_computations(path):
    logging.info(f"Starting computations for molecules in {path}\n")
    subprocess.run(["creafile", "sbatch_inpfile.txt"],cwd=path) # Counting the lines of sbatch_inpfile creates sbatch_array
    result = subprocess.run(["sbatch", "sbatch_array.sh"], capture_output=True, text=True,cwd=path)  # Submit the jobs
    
    job_id = None
    if result.returncode == 0 and "Submitted batch job" in result.stdout:
        output = result.stdout.strip()
        job_id = output.split()[-1]
        logging.info(f"Job submitted with ID: {job_id}")
    else:
        logging.error(f"Error during script submission: {result.stderr}")
        raise RuntimeError("Error during script submission!")

    # Step 2: Wait for the job to finish
    if job_id:
        while True:
            job = subprocess.run(["sacct", "-j", job_id, "--format=State", "--noheader"], capture_output=True, text=True)
            states = [s.strip() for s in job.stdout.splitlines() if s.strip()]

            # Condition: all COMPLETED
            if all(s == "COMPLETED" for s in states):
                return True

            if any(s in ["FAILED", "CANCELLED", "TIMEOUT"] for s in states):
                logging.error(f"Job {job_id} failed with states: {states}")
                raise RuntimeError(f"Job {job_id} failed with states: {states}")

            time.sleep(120)  # Check every 2 minutes

def convergence(listinput,outfile):
    logging.info(f"Checking the convergence of molecules in {listinput}\n")
    message:list[str] = check(input_dirs=[listinput], output=outfile, not_conv=True) # Possible PCM error to be implemented
    molid:list[str] = []
    while message:
        if any('discarded' in g for g in message):
            # Some molecules need to be discarded
            for mex in message:
                if 'discarded' in mex:
                    molid.append(mex.strip().split()[0])
            return molid
        else:
            logging.info(f"Convergence hasn\'t been reached for all molecules in {listinput}\n")
            # Some molecules have not converged for the first or second time, or there is a PCM error (to be added)
            send_computations(listinput)
            removeslurm(listinput)
            # Once the jobs are done, check if there are still convergence issues
            message = check(input_dirs=[listinput], output=outfile, not_conv=True)  # Possibility of PCM error to be added
    else: # No convergence issues
        logging.info(f"Convergence reached for all molecules in {listinput}\n")
        return molid

def imaginary_freq(listinput, outfile):
        logging.info(f"Checking if there are any imaginary frequencies in {listinput}\n")
        subprocess.run("module load gaussian/16 && super_fchk.sh", shell=True, cwd=listinput)
        message: list[str] = check(input_dirs=[listinput], output=outfile,nfreq=True)
        molid: list[str] = []
        counter=0
        while message and counter<3: # Negative frequencies found. At most 3 attempts
            logging.info(f"Imaginary frequencies found for some molecules in {listinput}\n")
            send_computations(listinput)
            removeslurm(listinput)
            message = check(input_dirs=[listinput], output=outfile,nfreq=True)
            counter+=1
        else:
            files = glob.glob(f"{listinput}/*.fchk")
            for f in files:
                subprocess.run(["rm", f])

def removeslurm(path):
    for f in glob.glob(f"{path}/slurm*.out"):
        Path(f).unlink(missing_ok=True)

def createformchk(path):
    result = subprocess.run("super_fchk.sh", capture_output=True, text=True,cwd=path)
    if result.returncode !=0:
        raise Exception(f"Couldn\'t create formatted checkpoint files in {path}\n")


def main():
    inp = argparse.ArgumentParser(description="Automatic algorithm")

    inp.add_argument("-i", "--input", help="Path input files", required=True) # Directory containing the S0 output files
    inp.add_argument("-o", "--output", help="Path output file", required=True) # Name of the output file to create in every directory

    args = inp.parse_args()

    s0path = Path(args.input)
    s0output=s0path/args.output

    # FIRST STEP: CHECKING IF ALL S0 FILES HAVE CONVERGED
    discarded_molecules = convergence(s0path,s0output)
    createformchk(s0path)

    # SECOND STEP: VERTICAL COMPUTATIONS

    # T1 TD-DFT AT S0 GEOMETRY
    logging.info("Starting T1 vertical computations")
    if discarded_molecules: # Some molecules need to be discarded
        for disc in discarded_molecules:
            discchk =Path(disc).with_suffix(".chk")
            discout =Path(disc).with_suffix(".out")
            # Remove the chk files in the S0 path of discarded molecules so they will no longer be considered
            subprocess.run(["rm",f"{discchk}",f"{discout}"])

    t1vertpath = s0path / 'verticale/t1'
    os.makedirs(f"{t1vertpath}", exist_ok=True)
    # Create new input files in the new folder starting from the S0 chk files
    check(comp=True, path=s0path, newext='_t1_vert', newpath=t1vertpath,method='td(nstates=3,root=1,triplets)',vert=True)
    # Submit the T1 vertical calculations
    send_computations(t1vertpath)
    removeslurm(t1vertpath)
    t1vertoutput= t1vertpath / args.output
    discarded_flagged = check(input_dirs=[t1vertpath],output=t1vertoutput,de_excitations=True,energy=True)
    if discarded_flagged:
        for disflag in discarded_flagged:
            if 'discarded' in disflag:
                disc = disflag.strip().split()[0]
                discarded_molecules.append(disc)
                disc = disc.replace('_t1_vert.chk', '.chk')
                discnoext = str(s0path / Path(disc).stem) # .stem returns only the filename without extension and without path
                # Remove the chk files of discarded molecules so they will no longer be considered
                subprocess.run(["rm",f"{discnoext}.chk",f"{discnoext}.out"])

    # S1 TD-DFT AT S0 GEOMETRY
    logging.info("Starting S1 vertical computations\n")

    s1vertpath = s0path / 'verticale/s1'
    os.makedirs(f"{s1vertpath}", exist_ok=True)
    # Create new input files in the new folder starting from the S0 chk files
    check(comp=True, path=s0path, newext='_s1_vert', newpath=s1vertpath,method='td(nstates=3,root=1)',vert=True)
    # Submit the S1 vertical calculations
    send_computations(s1vertpath)
    removeslurm(s1vertpath)
    s1vertoutput = s1vertpath / args.output
    discarded_flagged = check(input_dirs=[s1vertpath],output=s1vertoutput,de_excitations=True,energy=True)
    if discarded_flagged:
        for disflag in discarded_flagged:
            if 'discarded' in disflag:
                disc = disflag.strip().split()[0]
                discarded_molecules.append(disc)
                disc = disc.replace('_s1_vert.chk','.chk')
                discnoext = str(s0path / Path(disc).stem)
                # Remove the chk files of discarded molecules so they will no longer be considered
                subprocess.run(["rm", f"{discnoext}.chk", f"{discnoext}.out"])

    # THIRD STEP: DELTASCF T1 OPTIMIZATIONS
    logging.info("Starting T1 DeltaSCF optimization\n")

    t1scfpath=s0path.parent / "T1"
    os.makedirs(f"{t1scfpath}", exist_ok=True)
    # Create new input files in the new folder starting from the S0 chk files
    check(comp=True, path=s0path, newext='_t1', newpath=t1scfpath, method='DSCF')
    # Submit the S1 vertical calculations
    send_computations(t1scfpath)
    removeslurm(t1scfpath)
    createformchk(t1scfpath)
    logging.info("Computation Completed!\n")
    t1scfoutput= t1scfpath/ args.output
    # Have the T1 computations converged?
    conv = convergence(t1scfpath, t1scfoutput)
    if conv: # Some molecules haven't converged
        discarded_molecules.extend(conv)
        for c in conv:
            cpath = Path(c)
            disc = t1scfpath / cpath.stem
            discs0 = s0path / cpath.stem
            discs0 = discs0.with_name(discs0.name.replace('_t1',''))
            subprocess.run(["rm", f"{disc}.chk", f"{disc}.out",f"{discs0}.out",f"{discs0}.chk"]) # removing files from the S0 folder

    # Checking the connectivity
    logging.info(f"Checking the connectivity between {s0path} and {t1scfpath}")
    connectivity_check=check(input_dirs=[s0path,t1scfpath], output=t1scfoutput, connectivity=True)
    if connectivity_check:
        for cc in connectivity_check:
            cc = cc.strip().split()[0]
            pathcc = Path(cc)
            discarded_molecules.append(cc)
            discs0 = s0path / pathcc.stem
            disc = t1scfpath / pathcc.stem
            discs0 = discs0.with_name(discs0.name.replace('_t1',''))
            subprocess.run(["rm", f"{discs0}.chk", f"{discs0}.out",f"{disc}.out",f"{disc}.chk"]) # removing files from the S0 and T1 folders

    # T1 TD-DFT SINGLE POINT FROM T1 DSCF GEOMETRY
    logging.info("T1 TDDFT Single Point from DeltaSCF geometry\n")
    
    t1vert = t1scfpath / 'tddft_vert'
    os.makedirs(f"{t1vert}", exist_ok=True)
    # Create new input files in the new folder starting from the T1 chk files
    check(comp=True, path=t1scfpath, newext='_td_vert', newpath=t1vert, method='td(nstates=3,root=1,triplets)',
          vert=True)
    # Submit the T1 vertical calculations
    send_computations(t1vert)
    removeslurm(t1vert)
    logging.info("Computation Completed!\n")
    t1tdoutput = t1vert / args.output
    discarded_flagged = check(input_dirs=[t1vert], output=t1tdoutput, de_excitations=True, energy=True)
    if discarded_flagged:
        for disflag in discarded_flagged:
            if 'discarded' in disflag:
                disc = disflag.strip().split()[0]
                discarded_molecules.append(disc)
                discpath = Path(disc)
                discs0 = s0path / discpath.stem
                disc = t1vert / discpath.stem
                discs0 = discs0.with_name(discs0.name.replace('_t1_td_vert', ''))
                # Remove the chk files of discarded molecules so they will no longer be considered
                subprocess.run(["rm",f"{discs0}.chk",f"{discs0}.out",f"{disc}.chk",f"{disc}.out"])

    # FOURTH STEP: S1 TD-DFT OPTIMIZATIONS
    logging.info("Starting S1 TD-DFT optimization\n")

    s1tdpath=s0path.parent / "S1"
    os.makedirs(f"{s1tdpath}", exist_ok=True)
    # Create new input files in the new folder starting from the S0 chk files
    check(comp=True, path=s0path, newext='_s1', newpath=s1tdpath, method='td(nstates=3,root=1)')
    # Submit the S1 vertical calculations
    send_computations(s1tdpath)
    removeslurm(s1tdpath)
    createformchk(s1tdpath)
    logging.info("Computation Completed!\n")
    s1tdoutput= s1tdpath/ args.output
    # Have the S1 computations converged?
    conv = convergence(s1tdpath,s1tdoutput)
    if conv: # Some molecules haven't converged
        discarded_molecules.extend(conv)
        for c in conv:
            disc_conv = Path(c).stem
            disc = s1tdpath / disc_conv
            disct1 = t1scfpath / disc_conv
            discs0 = s0path / disc_conv
            discs0 = discs0.with_name(discs0.name.replace('_s1',''))
            disct1 = disct1.with_name(disct1.name.replace('_s1','_t1'))
            subprocess.run(["rm", f"{disc}.chk", f"{disc}.out",f"{discs0}.out",f"{discs0}.chk",f"{disct1}.chk",f"{disct1}.out"]) # removing files from the S0, S1 and T1 folders

    # Checking the connectivity
    logging.info(f"Checking the connectivity between {s0path} and {s1tdpath}")
    connectivity_check=check(input_dirs=[s0path,s1tdpath], output=s1tdoutput, connectivity=True)
    if connectivity_check:
        for cc in connectivity_check:
            cc = cc.strip().split()[0]
            pathcc = Path(cc)
            discarded_molecules.append(cc)
            disc = s1tdpath / pathcc.stem
            discs0 = s0path / pathcc.stem
            disct1 = t1scfpath / pathcc.stem
            discs0 = discs0.with_name(discs0.name.replace('_s1',''))
            disct1 = disct1.with_name(disct1.name.replace('_s1','_t1'))
            subprocess.run(["rm", f"{disc}.chk", f"{disc}.out",f"{discs0}.out",f"{discs0}.chk",f"{disct1}.out",f"{disct1}.chk"]) # removing files from the S0, S1 and T1 folders

    # FIFTH STEP: FREQUENCY COMPUTATION

    logging.info("Starting T1 frequency computation")

    t1freqpath = t1scfpath / "freq"
    os.makedirs(f"{t1freqpath}", exist_ok=True)
    # Create new input files in the new folder starting from the T1 chk files
    check(comp=True, path=t1scfpath, newext='_freq', newpath=t1freqpath, method='freq=hpmodes')
    # Submit the frequency calculations
    send_computations(t1freqpath)
    removeslurm(t1freqpath)
    createformchk(t1freqpath)
    logging.info("Computation Completed!\n")
    t1freqoutput = t1freqpath / args.output
    # Negative Frequencies?
    ifreq_molecules = imaginary_freq(t1freqpath,t1freqoutput)  # IDs of molecules that still have negative frequencies

    logging.info("Starting S1 frequency computation")

    s1freqpath = s1tdpath / "freq"
    os.makedirs(f"{s1freqpath}", exist_ok=True)
    # Create new input files in the new folder starting from the S1 chk files
    check(comp=True, path=s1tdpath, newext='_freq', newpath=s1freqpath, method='freq=hpmodes')
    # Submit the frequency calculations
    send_computations(s1freqpath)
    removeslurm(s1freqpath)
    createformchk(s1freqpath)
    logging.info("Computation Completed!\n")
    s1freqoutput = s1freqpath / args.output
    # Negative Frequencies?
    ifreq_molecules = imaginary_freq(s1freqpath, s1freqoutput)  # IDs of molecules that still have negative frequencies

if __name__=="__main__":
    main()
