import glob
from mylib import Mylib
import numpy as np
from concurrent.futures import ProcessPoolExecutor
import logging
from pathlib import Path

# This code is specifically configured to run in the author's local computational environment
# and was used as-is to produce the results in "Computation of Non-Radiative Rates for High-Throughput
# Virtual Screening: Application to Discovery of Potential TADF Molecules" by Teodoro Pizza, Alessandro Troisi and Amedeo Capobianco.


logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    filename='sample.log',
    filemode='a'
)

def new_comp(path:str, newext:str,newpath:str,method:str,vert=False):
    chk_files = sorted(glob.glob(f'{path}/*.chk'))

    logging.info(f"Creating new path: {newpath}\n")
    newpath = Path(newpath)

    with open(newpath/'sbatch_inpfile.txt', 'w') as _:
        pass

    for file in chk_files:
        ft = Path(file)
        ftt = ft.with_suffix(".out")
        obj = Mylib(ftt)
        obj.compinfo()
        keyword_parts=obj.keyword.strip().split()

        nametot = ft.stem 
        newfile = newpath / f"{nametot}{newext}.inp"
        outfile = newpath / f"{nametot}{newext}.out"
        namenoext = newfile.with_suffix("") 
        with open(newpath/'sbatch_inpfile.txt', 'a') as inp:
            inp.write(f"{newfile}\t")
            inp.write(f"{outfile}\n")
        with open(newfile, 'w') as nf:
            if vert:
                keyword_parts = [key for key in keyword_parts if 'opt' not in key and 'freq' not in key]
                if method=='td(nstates=3,root=1,triplets)': #TDDFT single point on Triplet DeltaSCF geometry
                    obj.molt=1
            else:
                if method=='DSCF':
                    obj.molt=3
                if method=='freq=hpmodes':
                    keyword_parts=[key for key in keyword_parts if 'opt' not in key]
                else:
                    keyword_parts=[key for key in keyword_parts if 'freq' not in key]

            obj.keyword = ' '.join(keyword_parts)
            elements = [obj.keyword, method]
            filtered = [el for el in elements if 'DSCF' not in el]
            if 'geom=check' not in obj.keyword:
                filtered.append('geom=check')

            newkey = ' '.join(filtered)

            header = [
                f"{obj.mem}",
                f"{obj.nproc}",
                f"%oldchk={file}",
                f"%chk={namenoext}",
                f"{newkey}",
                "",
                "title\n",
                f"{obj.charge} {obj.molt}\n"]

            nf.write("\n".join(header))
            nf.write("\n")
            if "scrf" in obj.keyword and "read" in obj.keyword:
                nf.write("eps=4.0\n\n")

def analize_single_file(g16out,de_excitations=False,energy=False,not_conv=False,nfreq=False):
    file = Mylib(g16out)
    file.compinfo()
    result=[]
    if de_excitations:
        logging.info("Checking for de-excitations\n")
        result.append(file.isdex())
    if energy:
        logging.info("Checking for energy values\n")
        result.append(file.encheck())
    if not_conv:
        logging.info("Checking for convergence\n")
        result.append(file.notconv('so far','Standard orientation','Rotational constants'))
    if nfreq:
        logging.info("Checking for negative frequencies\n")
        result.append(file.ifreq())
    return "\n".join([r for r in result if r])

def compare_connectivity(g16s1,g16s2):
    state1 = Mylib(g16s1)
    state2 = Mylib(g16s2)
    if not np.array_equal(state1.connect(),state2.connect()):
        return f'{g16s2} doesn\'t have the same connectivity as the S0 state'


def check(input_dirs=[],output='',**kwargs):
    de_excitations = kwargs.get('de_excitations', False)
    energy = kwargs.get('energy', False)
    connectivity = kwargs.get('connectivity', False)
    not_conv = kwargs.get('not_conv', False)
    nfreq = kwargs.get('nfreq', False)
    comp = kwargs.get('comp', False)
    path = kwargs.get('path', '')
    newext = kwargs.get('newext', '')
    newpath = kwargs.get('newpath', '')
    method = kwargs.get('method', '')
    vert = kwargs.get('vert',False)

    messages=[]

    if comp:
        new_comp(path,newext,newpath,method,vert)
        return messages

    if not input_dirs:
        raise Exception("Input files are missing!")

    if not output:
        raise Exception("Output file is missing!")

    if len(input_dirs) < 2:
        ex_files = sorted(glob.glob(f'{input_dirs[0]}/*.out'))
        with ProcessPoolExecutor(max_workers=4) as executor:
            par_exec=[
                executor.submit(analize_single_file,g16out.strip(),de_excitations,energy,not_conv,nfreq)
                for g16out in ex_files if g16out.strip()
            ]
            for p in par_exec:
                result = p.result()
                if result:
                    messages.append(result)

            if connectivity:
                raise Exception("2 input geometries are required for a connectivity check!")

    else:
        i1_files = sorted(glob.glob(f'{input_dirs[0]}/*.out'))
        i2_files = sorted(glob.glob(f'{input_dirs[1]}/*.out'))
        with ProcessPoolExecutor(max_workers=4) as executor:
            par_exec1=[
                executor.submit(analize_single_file,g16out.strip(),de_excitations,energy,not_conv,nfreq)
                for g16out in i1_files if g16out.strip()
            ]
            for p in par_exec1:
                result = p.result()
                if result:
                    messages.append(result)

            par_exec2=[
                executor.submit(analize_single_file,g16out.strip(),de_excitations,energy,not_conv,nfreq)
                for g16out in i2_files if g16out.strip()
            ]
            for p in par_exec2:
                result = p.result()
                if result:
                    messages.append(result)

        if connectivity:
            logging.info(f"Computing connectivity matrix to find geometry differences between {input_dirs[0]} and {input_dirs[1]}\n")
            if len(i1_files) != len(i2_files):
                raise Exception("The same number of files is needed in order to compare connectivity!")
            with ProcessPoolExecutor(max_workers=4) as executor:
                par_exec = [
                    executor.submit(compare_connectivity, g16s1.strip(), g16s2.strip())
                    for g16s1,g16s2 in zip(i1_files,i2_files)
                    if g16s1.strip() and g16s2.strip()
                ]
                for p in par_exec:
                    result = p.result()
                    if result:
                        messages.append(result)

    if messages:
        with open(output,"w") as out:
            out.write("\n".join(messages))

    return messages

