import subprocess
import numpy as np
from scipy.spatial.distance import pdist,squareform
from pathlib import Path

# This code is specifically configured to run in the author's local computational environment
# and was used as-is to produce the results in "Computation of Non-Radiative Rates for High-Throughput
# Virtual Screening: Application to Discovery of Potential TADF Molecules" by Teodoro Pizza, Alessandro Troisi and Amedeo Capobianco.


class Mylib:
    def __init__(self,filename):
        self.filename=filename
        self.charge=None
        self.molt=None
        self.nproc=None
        self.mem=None
        self.keyword=None

    def compinfo(self):
        with open(self.filename,'r') as f:
            lines=f.readlines()

            nproc = [l for l in lines if "%nproc" in l]
            mem = [m for m in lines if "%mem" in m]
            self.nproc = nproc[0].strip()
            self.mem = mem[0].strip()

            charge_molt = [line for line in lines if "Charge =" in line]
            self.charge = charge_molt[0].strip().split()[2]
            self.molt = charge_molt[0].strip().split()[-1]

            for l,(line, next_line) in enumerate(zip(lines, lines[1:])):
                if '#p' in line:
                    self.keyword = line.strip()
                    n=l+1
                    while n < len(lines) and '---' not in lines[n]:
                        self.keyword = ''.join([self.keyword,lines[n].strip()])
                        n+=1
                elif self.keyword:
                    break

    def isdex(self):
        with open(self.filename,'r',encoding="utf-8") as f:
            first_line =f.readline().strip()
            if not first_line.startswith('Entering Gaussian System, Link 0=g16'):
                raise Exception(f'{self.filename} is not a valid Gaussian output file!')
            for line in f:
                if '<-' in line:
                    return f'{self.filename}: De-excitation found. Molecule has to be discarded!'

    def encheck(self):
        with open(self.filename,'r',encoding="utf-8") as f:
            for line in f:
                if line.strip().startswith('Excited State   1:'):
                    colonne=line.split()
                    energia=float(colonne[4])
                    if 1.7 > energia > 0.0:
                        return f'{self.filename}: The excitation energy may be too small.'
                    elif energia < 0.0:
                        return f'{self.filename}: The excitation energy is negative. Molecule has to be discarded!'

    def connect(self):
        fname = Path(self.filename)
        new_filename = fname.with_suffix(".fchk")
        with open(new_filename, 'r',encoding="utf-8") as f:
            lines = f.readlines()
            for i, line in enumerate(lines):
                if 'Atomic numbers' in line:
                    parts = line.split()
                    num_atoms = int(parts[-1])
                    num_to_extract = num_atoms * 3  # 3N = 3*number of atoms
                    atnum = []
                    indx = i + 1
                    while len(atnum) < num_atoms:
                        line = lines[indx]
                        parts = line.split()
                        try:
                            next_atnum = [int(num) for num in parts]
                            atnum.extend(next_atnum)
                        except ValueError:
                            break
                        indx += 1
            for i, line in enumerate(lines):
                if 'Current cartesian coordinates' in line:
                    coords = []
                    indx = i + 1
                    while len(coords) < num_to_extract:
                        line = lines[indx]
                        parts = line.split()
                        next_coords = [num for num in parts]
                        coords.extend(next_coords)
                        indx += 1
                    break

        atnumbers = np.array(atnum, dtype=int)
        coordinates = np.reshape(np.array(coords, dtype=float), (num_atoms, 3))

        b2a = 0.52917721092
        coordinates = coordinates * b2a  # Now the coordinates are in Angstroem

        # ZR: atomic numbers (key)
        # cov. radii in Angstroem (value)
        ZR = {1: 0.23,
              2: 1.50,
              3: 0.68,
              4: 0.35,
              5: 0.84,
              6: 0.68,
              7: 0.68,
              8: 0.68,
              9: 0.64,
              10: 1.50,
              11: 0.97,
              12: 1.10,
              13: 1.35,
              14: 1.20,
              15: 1.05,
              16: 1.02,
              17: 0.99,
              18: 1.51,
              19: 1.33,
              20: 0.99,
              26: 1.34,
              27: 1.33,
              28: 1.50,
              29: 1.52,
              30: 1.45,
              35: 1.14,
              53: 1.36}

        # C(j, i) will return 1 if atoms i and j, are bonded. The criterion for the existence of a bond is the one used in most
        # crystallographic programs: i and j are bonded if their distance(d) is in the range(Rcov(i) + Rcov(j) + / - tol),
        # where tol is a tolerance, set to 0.4 Angstrom according to Cambridge struct.database
        tol = 0.4
        # squareform creates a symmetric square matrix with zeros on the diagonal
        # from the vector generated by pdist. The latter contains
        # all pairwise distances between the Cartesian coordinates of the atoms.        dists = squareform(pdist(coordinates))
        radii = np.vectorize(ZR.get)(atnumbers) # crea un vettore contenente i raggi presi dal dizionario ZR usando come
        # key: the atomic numbers vector
        # radii[:, None] converts a row vector into a column vector. The sum radii[:, None] + radii
        # uses broadcasting to generate an NxN matrix containing all possible sums of the radii
        # to be compared with the distance matrix dists       
        rcov_matrix = radii[:, None] + radii + tol
        # compares distances with the matrix of summed covalent radii
        conmat = (dists <= rcov_matrix).astype(int)  # astype(int) converts True to 1 and False to 0
        np.fill_diagonal(conmat, 0)  # removes self-connections       
        return conmat

    def notconv(self,sofar,storientation,rotconst):
        with open(self.filename,'r',encoding="utf-8") as f:
            lines=f.readlines()

            if 'Normal' not in lines[-1].strip(): # Computation hasn't terminated normally

                new_coord=[]

                for i in range(len(lines)-1,-1,-1): 
                    if sofar in lines[i]:
                        sofar_index=i
                        break

                for i in range(sofar_index, -1, -1):
                    if storientation in lines[i]:
                        stor_index = i
                        break

                for i in range(stor_index, len(lines) - 1):
                    if rotconst in lines[i]:
                        rotc_indx = i
                        break
                for i in range(stor_index + 5, rotc_indx - 1):
                    if lines[i].strip():
                        parts = lines[i].split()
                        indx = [1, 3, 4, 5]
                        next_cord = [parts[j] for j in indx]
                        new_coord.extend(next_cord)

                for line in lines:
                    if 'No Z-matrix variables, so optimization will use Cartesian coordinates.' in line.strip():
                        return f"{self.filename}: No convergence after using cartesian coordinates. Molecule has to be discarded!"

                parts = self.keyword.strip().split()
                if any('opt' in s for s in parts):
                     if 'opt(maxstep=10,maxcycle=200)' in parts:
                         i = parts.index('opt(maxstep=10,maxcycle=200)')
                         parts[i] = 'opt(maxstep=5,maxcycle=100,calcfc)'
                         self.keyword=" ".join(parts)
                     elif 'opt(maxstep=5,maxcycle=100,calcfc)' in parts:
                         i = parts.index('opt(maxstep=5,maxcycle=100,calcfc)')
                         parts[i] = 'opt(cartesian,maxcycle=300)'
                         self.keyword=" ".join(parts)
                     else:
                         match = [elem for elem in parts if "opt" in elem]
                         i = parts.index(match[0])
                         parts[i] = 'opt(maxstep=10,maxcycle=200)'
                         self.keyword=" ".join(parts)

                fname = Path(self.filename)
                new_name = fname.with_name(fname.stem + "_sofar.inp")
                with open(new_name, 'w') as t:
                    header = [
                        f"{self.mem}",
                        f"{self.nproc}",
                        f"%chk={fname}",
                        f"{self.keyword}",
                        "",
                        "title\n",
                        f"{self.charge} {self.molt}\n"]
                    t.write("\n".join(header))
                    n = 0
                    for j in range(len(new_coord)):
                        t.write(f"{new_coord[j]}\t")
                        n += 1
                        if n == 4:
                            t.write("\n")
                            n = 0
                    t.write("\n")
                    if "scrf" in self.keyword and "read" in self.keyword:
                        t.write("eps=4.0\n\n")

                fpath = fname.parent
                with open(fpath/'sbatch_inpfile.txt', 'w') as sbf:
                    pass
                with open(fpath/'sbatch_inpfile.txt','a') as sbf:
                    fout = new_name.with_suffix(".out")
                    sbf.write(f"{new_name}\t")
                    sbf.write(f"{fout}\n")

            else:
                return False

    def ifreq(self):
        fname = Path(self.filename)
        ifile = fname.with_suffix(".inp")
        ofile = fname.with_suffix(".out")
        fpath = fname.parent
        fchk = fname.with_suffix(".fchk") 
        with open(fpath/'sbatch_inpfile.txt', 'w') as sbf:
            pass
        with open(fpath/'sbatch_inpfile.txt', 'a') as sbf:
            with open(fname,'r') as f:
                lines=f.readlines()
                imm_true=[True for line in lines if 'imaginary frequencies (negative Signs)' in line]
                if imm_true:
                    subprocess.run(["move_mode_single"],input=f"{fchk} {self.keyword} {self.charge} {self.molt} {self.mem} {self.nproc}", capture_output=True, text=True)
                    sbf.write(f"{ifile}\t")
                    sbf.write(f"{ofile}\n")
                    return f"{fname}: Imaginary frequency found"
                else:
                    return False



