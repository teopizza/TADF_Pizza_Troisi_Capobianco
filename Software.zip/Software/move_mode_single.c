    #include <stdio.h>
    #include <stdlib.h>
    #include <string.h>
    #include <math.h>
    #include <gsl/gsl_matrix.h>
    #include <gsl/gsl_blas.h>
    #include <gsl/gsl_vector.h>
    #include <gsl/gsl_eigen.h>
    #include <gsl/gsl_linalg.h>

    #define MAX_LINE_LENGTH 4096  // Increased buffer for safety

    int compare_doubles(const void *a, const void *b) {
        double diff = (*(double *)a - *(double *)b); // cast a and b to double [(double *)a] and then deferencing [*(double *)a], thus taking the actual value of a
        return (diff > 0) - (diff < 0); // Returns 1 if a > b, -1 if a < b, 0 otherwise
    }

    void normalization(gsl_matrix *m) {
        double norm = 0.0;

        // Compute norm
        for (size_t i = 0; i < m->size1; i++) {
            for (size_t j = 0; j < m->size2; j++) {
                double val = gsl_matrix_get(m, j, i);
                norm += pow(val,2);
            }
	    norm=sqrt(norm);
            if (norm == 0) return; // Avoid division by zero
            for (size_t k = 0; k < m->size2; k++) {
                double mat  = gsl_matrix_get(m, k, i);
                gsl_matrix_set(m, k, i, mat / norm);
            }
        }
    }

    void print_help(char *program_name){
	    printf("Usage: %s input_file\n",program_name);
	    printf("\n%s creates a Gaussian input file for every formchk file contained\n in the input_file, using default values for '%%mem','%%nproc' and all the other keywords.\n",program_name);
	    printf("\nThe coordinates inside the new Gaussian input files are obtained \n by moving on the PES of the first mode of the molecules, just like one can do in GaussView.\n");
    
    }


    void move_mode(const char *filename,const char *keyword, int carica, int molt,const char *mem,const char *nproc) {

        FILE *f = fopen(filename, "r");//Try to open input file
        if (!f) {
        fclose(f);
            fprintf(stderr, "Error: Could not open input file '%s'\n", filename);
            exit(EXIT_FAILURE);
        }

                char filename2[256];
                strcpy(filename2, filename);
                char *dot = strrchr(filename2, '.');
                if (dot) *dot = '\0';  // Remove file extension
                size_t num_atoms = 0;  // Number of atoms
                char line[MAX_LINE_LENGTH];

                // Find 'Atomic numbers' to get the number of atoms
                while (fgets(line, sizeof(line), f)) {
                    if (strstr(line, "Atomic numbers")) {
                        sscanf(line, "%*s %*s %*s %*s %zu", &num_atoms);
                        break;
                    }
                }

                size_t num_to_extract = num_atoms * 3;  // Each atom has 3 Cartesian coordinates
                size_t force_size = num_to_extract * (num_to_extract + 1) / 2; // numbers of elements in the upper triangular of the force constants matrix
                // Allocate memory
                double *cart_coord = (double *)malloc(num_to_extract * sizeof(double));
                double *atomic_masses = (double *)malloc(num_atoms * sizeof(double));
                double *fconst = (double *)malloc(force_size * sizeof(double));
                size_t *atomic_numbers = (size_t *)malloc(num_atoms * sizeof(size_t));

                if (!atomic_numbers ||  !cart_coord || !atomic_masses || !fconst) {
                    perror("Memory allocation failed");
                    fclose(f);
                    return;
            }
	rewind(f);
        size_t count = 0;
        while (fgets(line, sizeof(line), f)) {
            if (strstr(line, "Atomic numbers")) {
                count = 0;
                while (count < num_atoms && fgets(line, sizeof(line), f)) {
                    char *token = strtok(line, " ");
                    while (token && count < num_atoms) {
                        atomic_numbers[count++] = atoi(token);
                        token = strtok(NULL, " ");
                    }
                }
            } else if (strstr(line, "Current cartesian coordinates")) {
                count = 0;
                while (count < num_to_extract && fgets(line, sizeof(line), f)) {
                    char *token = strtok(line, " ");
                    while (token && count < num_to_extract) {
                        cart_coord[count++] = atof(token);
                        token = strtok(NULL, " ");
                    }
                }
            } else if (strstr(line, "Real atomic weights")) {
                count = 0;
                while (count < num_atoms && fgets(line, sizeof(line), f)) {
                    char *token = strtok(line, " ");
                    while (token && count < num_atoms) {
                        atomic_masses[count++] = atof(token);
                        token = strtok(NULL, " ");
                    }
                }
            }else if (strstr(line, "Cartesian Force Constants")) {
                count = 0;
                while (count < force_size * 3 && fgets(line, sizeof(line), f)) {
                    char *token = strtok(line, " ");
                    while (token && count < force_size) {
                        fconst[count++] = atof(token);
                        token = strtok(NULL, " ");
                    }
                }
            }
        }

        fclose(f);  // Close input file
        
	// Allocate and initialize to zero the gsl_vectors(num_elements) and gsl_matrices(row,columns)
	// needed to store the extracted quantities
        gsl_vector_int *z = gsl_vector_int_calloc(num_atoms);
        gsl_matrix *x = gsl_matrix_calloc(num_atoms,3);
        gsl_matrix *C = gsl_matrix_calloc(num_to_extract,num_to_extract);
        gsl_vector *m = gsl_vector_calloc(num_atoms);

	// Filling the gsl_vectors(matrices)
        count=0;
        for (size_t i=0;i<num_atoms;i++){
            for (size_t j=0;j<3;j++){
                gsl_matrix_set(x,i,j,cart_coord[count++]);
            }
        }

        count=0;
        for (size_t i=0;i<num_atoms;i++){
                gsl_vector_set(m,i,atomic_masses[count++]);
        }

        count=0;
        for (size_t i=0;i<num_atoms;i++){
                gsl_vector_int_set(z,i,atomic_numbers[count++]);
        }

        count=0;
        for (size_t i=0;i<num_to_extract;i++){
            for (size_t j=0;j<i+1;j++){
                gsl_matrix_set(C,j,i,fconst[count]);
                gsl_matrix_set(C,i,j,fconst[count]);
            count++;
            }
        }

	// Free memory
        free(atomic_numbers);
        free(cart_coord);
        free(atomic_masses);
        free(fconst);

	// COMPUTATION OF THE CENTER OF MASS
        double mtot=0.0; // total mass
        for (size_t i=0;i<num_atoms;i++){
            mtot += gsl_vector_get(m,i);
        }
	// Allocating memory for the centre of mass vector
        gsl_vector *CM = gsl_vector_alloc(3);

	// temporary coordinates matrix
        gsl_matrix *x_new = gsl_matrix_alloc(num_atoms,3);

        double b2a = 0.52917721092; // converts Bohr into Angstroem
        gsl_matrix_scale(x,b2a);

        gsl_matrix_memcpy(x_new,x);
        double sum_x=0.0, sum_y=0.0, sum_z = 0.0;
        //gsl_matrix_scale_rows(x_new,m);
        for (size_t i = 0; i < x_new->size1; ++i) {
            gsl_vector_view row = gsl_matrix_row(x_new, i);
            double s = gsl_vector_get(m, i);  // oppure scalari[i] se è un array C puro
            gsl_vector_scale(&row.vector, s);
        }
        for(size_t i=0;i<num_atoms;i++){
            sum_x += gsl_matrix_get(x_new,i,0);
            sum_y += gsl_matrix_get(x_new,i,1);
            sum_z += gsl_matrix_get(x_new,i,2);
        }
        gsl_vector_set(CM,0,sum_x);
        gsl_vector_set(CM,1,sum_y);
        gsl_vector_set(CM,2,sum_z);
        gsl_vector_scale(CM,pow(mtot,-1));
        gsl_matrix_free(x_new);

	// mass-weighted cartesian coordinates
        gsl_matrix *qM = gsl_matrix_alloc(num_atoms,3);

        double element = 0.0;
        for(size_t i=0;i<num_atoms;i++){
            for (size_t j=0;j<3;j++){
                element = gsl_matrix_get(x,i,j) - gsl_vector_get(CM,j);
                gsl_matrix_set(x,i,j,element);
                gsl_matrix_set(qM,i,j,element);
            }
        }
        gsl_vector_free(CM);

	// Diagonal 3*Num_atoms x 3*Num_atoms matrix containing the inverse square root masses
        gsl_matrix *M12m = gsl_matrix_calloc(num_to_extract,num_to_extract);

        size_t l;
        for(size_t i=0;i<num_atoms;i++){
                l=i*3;
            for(size_t j=l;j<l+3; j++){
                gsl_matrix_set(M12m,j,j,pow(sqrt(gsl_vector_get(m,i)),-1));
            }
        }

        //ECKART CONDITIONS
        gsl_vector *m_sqrt = gsl_vector_calloc(num_atoms);

        for (size_t i=0;i<num_atoms;i++){
            gsl_vector_set(m_sqrt,i,sqrt(gsl_vector_get(m,i)));
        }
        
        //gsl_matrix_scale_rows(qM,m_sqrt);
        for (size_t i = 0; i < qM->size1; ++i) {
            gsl_vector_view row = gsl_matrix_row(qM, i);
            double s = gsl_vector_get(m_sqrt, i);  // oppure scalari[i] se è un array C puro
            gsl_vector_scale(&row.vector, s);
        }
        gsl_matrix *I = gsl_matrix_alloc(3,3);

        gsl_vector *xv = gsl_vector_alloc(num_atoms);
        gsl_vector *yv = gsl_vector_alloc(num_atoms);
        gsl_vector *zv = gsl_vector_alloc(num_atoms);
        
        for (size_t i = 0; i < num_atoms; i++) {
            gsl_vector_set(xv, i, gsl_matrix_get(qM, i, 0));
            gsl_vector_set(yv, i, gsl_matrix_get(qM, i, 1));
            gsl_vector_set(zv, i, gsl_matrix_get(qM, i, 2));
        }
        
        double xx, yy, zz, Ixy, Ixz, Iyz, Ixx, Iyy, Izz;
        // Compute the elements of the inertia tensor I
        gsl_blas_ddot(xv, xv, &xx);
        gsl_blas_ddot(yv, yv, &yy);
        gsl_blas_ddot(zv, zv, &zz);
        
        gsl_blas_ddot(xv, yv, &Ixy);
        gsl_blas_ddot(xv, zv, &Ixz);
        gsl_blas_ddot(yv, zv, &Iyz);
        
        Ixy = -Ixy;
        Ixz = -Ixz;
        Iyz = -Iyz;
        
        Ixx = yy + zz;
        Iyy = xx + zz;
        Izz = xx + yy;
        
        gsl_matrix_set(I, 0, 0, Ixx);
        gsl_matrix_set(I, 0, 1, Ixy);
        gsl_matrix_set(I, 0, 2, Ixz);
        gsl_matrix_set(I, 1, 0, Ixy);
        gsl_matrix_set(I, 1, 1, Iyy);
        gsl_matrix_set(I, 1, 2, Iyz);
        gsl_matrix_set(I, 2, 0, Ixz);
        gsl_matrix_set(I, 2, 1, Iyz);
        gsl_matrix_set(I, 2, 2, Izz);
        
        gsl_vector_free(xv);
        gsl_vector_free(yv);
        gsl_vector_free(zv);

        gsl_vector *Iabc = gsl_vector_alloc(3);
        gsl_matrix *T = gsl_matrix_alloc(3,3);
        gsl_eigen_symmv_workspace *w = gsl_eigen_symmv_alloc(3);

	// T is the 3x3 matrix that diagonalizes I
        gsl_eigen_symmv(I,Iabc,T,w);
        // Free workspace
        gsl_eigen_symmv_free(w);

        // Sort eigenvalues and eigenvectors
        gsl_eigen_symmv_sort(Iabc, T, GSL_EIGEN_SORT_ABS_ASC);

        gsl_vector_free(Iabc);
        gsl_matrix_free(I);

	// Translational Eckart Coordinates
        gsl_matrix *Dtr = gsl_matrix_calloc(num_to_extract,3);
        
        size_t mm;
        for(size_t i=0;i<3;i++){
            for(size_t j=0;j<num_atoms;j++){
                mm=3*j+i;
            gsl_matrix_set(Dtr,mm,i,gsl_vector_get(m_sqrt,j));
            }
        }

        gsl_matrix *qM_praxes = gsl_matrix_alloc(num_atoms,3);
        gsl_blas_dgemm(CblasNoTrans, CblasNoTrans,1.0, qM, T, 0.0, qM_praxes);
        gsl_matrix_free(qM);

	// Rotational Eckart Coordinates
        gsl_matrix *Drot = gsl_matrix_calloc(num_to_extract,3);

	// Vector product between T and qM(i,:)
        size_t row;
        for (size_t i=0;i<3;i++){
            for (size_t j=0;j<num_atoms;j++){
                row=j*3+i;
                gsl_matrix_set(Drot,row,0,(gsl_matrix_get(qM_praxes,j,1)*gsl_matrix_get(T,i,2)-gsl_matrix_get(qM_praxes,j,2)*gsl_matrix_get(T,i,1)));
                gsl_matrix_set(Drot,row,1,(gsl_matrix_get(qM_praxes,j,2)*gsl_matrix_get(T,i,0)-gsl_matrix_get(qM_praxes,j,0)*gsl_matrix_get(T,i,2)));
                gsl_matrix_set(Drot,row,2,(gsl_matrix_get(qM_praxes,j,0)*gsl_matrix_get(T,i,1)-gsl_matrix_get(qM_praxes,j,1)*gsl_matrix_get(T,i,0)));
            }
        }

	// Traslational and rotational Eckart coordinates
        gsl_matrix *D_quasi = gsl_matrix_alloc(num_to_extract,6);

        size_t col;
        for(size_t i=0;i<6;i++){
            for(size_t j=0;j<num_to_extract;j++){
                if(i<3){
                gsl_matrix_set(D_quasi,j,i,gsl_matrix_get(Dtr,j,i));
                continue;
            }
        col=i-3;
            gsl_matrix_set(D_quasi,j,i,gsl_matrix_get(Drot,j,col));
            }
        }
        gsl_matrix_free(Drot);
        gsl_matrix_free(Dtr);
        gsl_matrix_free(qM_praxes);
        gsl_matrix_free(T);

        gsl_matrix *M12mC = gsl_matrix_alloc(num_to_extract,num_to_extract);
        gsl_matrix *f_mw = gsl_matrix_alloc(num_to_extract,num_to_extract);

	// Compute the matrix product f_mw = M12m*C*M12m
        gsl_blas_dgemm(CblasNoTrans, CblasNoTrans,1.0, M12m,C, 0.0, M12mC);
        gsl_blas_dgemm(CblasNoTrans, CblasNoTrans,1.0, M12mC, M12m, 0.0, f_mw);
        gsl_matrix_free(M12mC); 
        gsl_matrix_free(C);
        gsl_matrix *f_mw_copy = gsl_matrix_alloc(num_to_extract,num_to_extract);

        gsl_matrix_memcpy(f_mw_copy,f_mw);

	// Diagonalize f_mw (I do a copy because 'gsl_eigen_symmv' destroys it) to get L
        gsl_vector *lam = gsl_vector_alloc(num_to_extract);
        gsl_matrix *L = gsl_matrix_alloc(num_to_extract,num_to_extract);
        gsl_eigen_symmv_workspace *work = gsl_eigen_symmv_alloc(num_to_extract);

        gsl_eigen_symmv(f_mw,lam,L,work);
        // Free workspace
        gsl_eigen_symmv_free(work);

        // Sort eigenvalues and eigenvectors
        gsl_eigen_symmv_sort(lam, L, GSL_EIGEN_SORT_VAL_ASC);

        gsl_vector_free(lam);
        gsl_matrix_free(f_mw);

        gsl_matrix *D = gsl_matrix_calloc(num_to_extract,num_to_extract);

	// Columns that goes from 7 to 3*Num_atoms of D are the columns of L
        size_t column;
        for (size_t i=0;i<num_to_extract;i++) {
            column=6;
            for (size_t j=0;j<num_to_extract;j++) {
                if (j<6){
                gsl_matrix_set(D,i,j,gsl_matrix_get(D_quasi,i,j));
                continue;
                }
                gsl_matrix_set(D,i,j,gsl_matrix_get(L,i,column));
                column++;
            }
        }

	// Final D (Q_mat) is obtained after a QR decomposition (similar to Gram-Schmidt orthogonalization)
        gsl_matrix *Q_mat = gsl_matrix_calloc(num_to_extract,num_to_extract);
        gsl_matrix *R = gsl_matrix_alloc(num_to_extract,num_to_extract);
        gsl_vector *tau = gsl_vector_alloc(num_to_extract);

        gsl_linalg_QR_decomp(D, tau);

        gsl_linalg_QR_unpack(D, tau, Q_mat, R);

        gsl_matrix_free(R);
        gsl_vector_free(tau);
        gsl_matrix_free(D);

        gsl_matrix *Dtf_mw = gsl_matrix_calloc(num_to_extract,num_to_extract);
        gsl_matrix *f_int = gsl_matrix_calloc(num_to_extract,num_to_extract);

	// Compute the product f_int = D'*f_mw*D
        gsl_blas_dgemm(CblasTrans, CblasNoTrans,1.0,Q_mat,f_mw_copy, 0.0, Dtf_mw);
        gsl_blas_dgemm(CblasNoTrans, CblasNoTrans,1.0, Dtf_mw, Q_mat, 0.0, f_int);
        
        gsl_matrix_free(Dtf_mw);
        gsl_matrix_free(Q_mat);

	// Take the submatrix of f_int considering only the vibrational normal modes
        gsl_matrix *f_sub_int =gsl_matrix_alloc(num_to_extract-6,num_to_extract-6);

        size_t rf=0,cf;
        for(size_t i=6;i<num_to_extract;i++){
            cf=0;
            for(size_t j=6;j<num_to_extract;j++){
            gsl_matrix_set(f_sub_int,rf,cf,gsl_matrix_get(f_int,i,j));
            cf++;
        }
        rf++;
        }
        gsl_eigen_symm_workspace *worker = gsl_eigen_symm_alloc(num_to_extract-6);
        gsl_vector *lam_int = gsl_vector_alloc(num_to_extract-6);

	// Diagonalized to get lam_int used to double check where is the negative mode
	// so that I don't remove it when I remove the rotations and translations
        gsl_eigen_symm(f_sub_int,lam_int,worker);

        gsl_eigen_symm_free(worker);
        
	// sorting lam_int  in ascending order
        qsort(lam_int->data,num_to_extract-6,sizeof(double),compare_doubles);

	// Normalize L
        normalization(L);

        gsl_matrix *L_new = gsl_matrix_calloc(num_to_extract,num_to_extract-6);

	// move the first mode (imaginary frequency)
        double t = 0.565;
        gsl_vector *Q = gsl_vector_calloc(num_to_extract-6);
        gsl_vector_set(Q,0,t);

	// L_new = 3*Num_atoms x 3*Num_atoms-6 matrix considering only the vibrational modes
	size_t col2=0;
        for(size_t i=0;i<num_to_extract-6;i++){
            if (lam_int->data[i]<0.0){
            for (size_t j=0;j<num_to_extract;j++){
                gsl_matrix_set(L_new,j,col2,gsl_matrix_get(L,j,i));
            }
                col2++;
                printf("\nImaginary Frequency found in %s\n",filename2);
            }
        }

        gsl_vector_free(lam_int);
        gsl_matrix_free(f_sub_int);
        gsl_matrix_free(f_int);
        gsl_matrix_free(f_mw_copy);

        size_t start_indx=col2+6;
        for (size_t i=start_indx;i<num_to_extract;i++){
            for (size_t j=0;j<num_to_extract;j++){
                gsl_matrix_set(L_new,j,col2,gsl_matrix_get(L,j,i));
        }
            col2++;
        }

        gsl_matrix_free(L);

        gsl_matrix *M12mL = gsl_matrix_alloc(num_to_extract,num_to_extract-6);
        gsl_vector *M12mLQ = gsl_vector_alloc(num_to_extract);

	// Matrix product M12m*L*Q
        gsl_blas_dgemm(CblasNoTrans, CblasNoTrans,1.0, M12m, L_new, 0.0, M12mL);
        gsl_blas_dgemv(CblasNoTrans,1.0, M12mL, Q, 0.0, M12mLQ);

        gsl_matrix_free(M12mL);
        gsl_matrix_free(M12m);
        gsl_matrix_free(L_new);
        gsl_vector_free(Q);

        gsl_vector *x_vector = gsl_vector_alloc(num_to_extract);

	// The new caartesian coordinates, after moving on the PES 
	// of the mode with the imaginary frequency, are given by x = x + M12m*L*Q
        size_t k;
        for(size_t i=0;i<num_atoms;i++){
            k=3*i;
            gsl_vector_set(x_vector,k,gsl_matrix_get(x,i,0));
            gsl_vector_set(x_vector,k+1,gsl_matrix_get(x,i,1));
            gsl_vector_set(x_vector,k+2,gsl_matrix_get(x,i,2));
        }

        gsl_matrix_free(x);
        gsl_vector_add(x_vector,M12mLQ);
        gsl_vector_free(M12mLQ);

        // Create output filename
        char output_file[260];
        snprintf(output_file, sizeof(output_file), "%s_ifreq.inp", filename2);
        FILE *newfile = fopen(output_file, "w");
        if (!newfile) {
            perror("Error opening output file");
            return;
        }


        fprintf(newfile,"%s",mem);
        fprintf(newfile,"%%chk=%s\n",filename2);
        fprintf(newfile,"%s",nproc);
        
        fprintf(newfile,"%s\n",keyword);
        fprintf(newfile,"\ntitolo\n");
        fprintf(newfile,"\n%d %d\n",carica,molt);
        size_t s;
        for (size_t i=0;i<num_atoms;i++){
                s=i*3;
                fprintf(newfile,"%u\t",gsl_vector_int_get(z,i));
            for(size_t j=s;j<s+3;j++){
                    if (j==s+2){
                            fprintf(newfile,"%lf\n",gsl_vector_get(x_vector,j));
                            continue;
                    }
                    fprintf(newfile,"%lf\t",gsl_vector_get(x_vector,j));
            }
        }
        fprintf(newfile,"\n");


        gsl_vector_free(x_vector);
        gsl_vector_int_free(z);
    }


    // Main function
    //
int main(int argc, char *argv[]) {
    if (argc < 5) {
        fprintf(stderr, "Usage: %s file keyword carica molt\n", argv[0]);
        return 1;
    }

    const char *filename = argv[1];
    const char *keyword = argv[2];
    const char *mem = argv[5];
    const char *nproc = argv[6];
    int carica = atoi(argv[3]);
    int molt = atoi(argv[4]);

    move_mode(filename, keyword, carica, molt, mem, nproc);
    return 0;
}

